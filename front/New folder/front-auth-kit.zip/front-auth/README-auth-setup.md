# Front-end login/register + email OTP — setup notes

## 1. Run the SQL
Run `sql/001_front_auth_migration.sql` against your existing
`u424007618_Developers` database. It only ALTERs `users` (adds
`email_verified_at`, `status`) and creates one new table, `email_otps`.
Nothing existing is dropped or renamed.

## 2. Drop the PHP files into place
```
front/profile.php
front/includes/auth-modal.php
front/includes/login.php
front/includes/logout.php
front/includes/register-send-otp.php
front/includes/register-verify-otp.php
front/includes/update-profile.php
front/includes/otp-functions.php
front/includes/mailer.php
```

## 3. Wire the modal into your existing header
Your `header.php` already has a link pointing at `#authModal`
(`LOGIN / REGISTER`) but that modal doesn't exist yet. Add this one line
near the bottom of `header.php`, after the wishlist off-canvas markup:

```php
<?php require_once __DIR__ . '/auth-modal.php'; ?>
```

## 4. Configure email sending
Install PHPMailer (recommended over PHP's `mail()`, which most hosts
spam-filter or block):
```
composer require phpmailer/phpmailer
```
Then open `front/includes/mailer.php` and fill in your real SMTP host,
username, and password.

## 5. Turn the header's "Post Property" / login link into what you want
Currently `login-dropdown-title` in `header.php` already targets
`#authModal` via `data-bs-toggle="modal" data-bs-target="#authModal"` —
no change needed there, it'll now open the real modal.

## How it works
- **Register**: user fills the form → `register-send-otp.php` validates,
  emails a 6-digit code, and stashes the pending signup in the PHP
  session (nothing is written to `users` yet).
- **Verify**: user enters the code → `register-verify-otp.php` checks it
  against the hashed OTP in `email_otps`, then (only now) inserts the row
  into `users` with `email_verified_at = NOW()` and logs them in.
- **Login**: `login.php` checks `username` (your existing email column)
  + `password` against the same `users` table, same as your admin login,
  just without requiring `role = 'admin'`.
- **Profile**: `profile.php` is a protected page gated on
  `$_SESSION['front_user_id']`; it reads/updates the same `users` row,
  including photo upload into the same `backend/uploads/profile/`
  folder you're already using for admins.

## Notes / things worth deciding
- I added `status` (Active/Inactive) so you can disable an account later
  without deleting it — `login.php` already checks it.
- I added a UNIQUE key on `users.username` (your email column) in the
  migration — remove that line if you currently have duplicate emails in
  there, and dedupe first.
- OTPs are stored **hashed**, expire in 10 minutes, and lock after 5 wrong
  attempts per code.
- This reuses your existing session — if your admin backend also uses
  `$_SESSION`, make sure key names don't collide (I used
  `front_user_id` / `front_user_name` / `front_user_email` to keep them
  separate from any `admin_id` style keys your backend already sets).
