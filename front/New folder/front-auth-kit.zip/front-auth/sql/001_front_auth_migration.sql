-- ============================================================
-- Front-end (customer) login/register + email OTP verification
-- Run this against the SAME database (u424007618_Developers)
-- that already has your `users` table.
-- ============================================================

-- 1) Extend the existing users table.
--    - email_verified_at: NULL until OTP is confirmed
--    - status: lets you disable a front account without deleting it
ALTER TABLE `users`
  ADD COLUMN `email_verified_at` DATETIME DEFAULT NULL AFTER `username`,
  ADD COLUMN `status` ENUM('Active','Inactive') NOT NULL DEFAULT 'Active' AFTER `role`;

-- Mark all your EXISTING rows (admins + prior users) as already verified,
-- so this change doesn't lock anyone out.
UPDATE `users` SET `email_verified_at` = `created_at` WHERE `email_verified_at` IS NULL;

-- Make sure the email column (`username`) can't be duplicated.
-- (Skip this if you already have duplicate emails in there — clean those up first.)
ALTER TABLE `users` ADD UNIQUE KEY `uq_users_username` (`username`);

-- 2) New table: short-lived OTP codes for registration/login/reset.
--    We store a HASH of the OTP, never the raw code, same idea as passwords.
CREATE TABLE `email_otps` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(150) NOT NULL,
  `otp_hash` VARCHAR(255) NOT NULL,
  `purpose` ENUM('register','login','reset') NOT NULL DEFAULT 'register',
  `attempts` TINYINT(3) NOT NULL DEFAULT 0,
  `expires_at` DATETIME NOT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email_purpose` (`email`, `purpose`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
