<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';

if (empty($_SESSION['front_user_id'])) {
    // Not logged in — send home; header.php's login modal handles auth.
    header('Location: /front/?login=1');
    exit;
}

$userId = (int) $_SESSION['front_user_id'];
$stmt = $conn->prepare("SELECT fullname, username, mobile_number, profile_image, created_at FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: /front/includes/logout.php');
    exit;
}

$avatarPath = !empty($user['profile_image'])
    ? '/' . ltrim($user['profile_image'], '/')
    : '/front/assets/images/default-avatar.png';

require_once __DIR__ . '/includes/header.php';
?>
<style>
  .profile-wrap{ max-width:640px; margin:2.5rem auto; padding:0 1rem; }
  .profile-card{ border:1px solid #e7e9ee; border-radius:1rem; padding:2rem; }
  .profile-avatar{ width:96px; height:96px; border-radius:50%; object-fit:cover; border:1px solid #e7e9ee; }
  .profile-card .form-label{ font-weight:600; font-size:.9rem; }
  #profileSaveBtn{ background:#1f6feb; border:none; }
  #profileAlert{ display:none; }
</style>

<div class="profile-wrap">
  <div class="profile-card">
    <div class="d-flex align-items-center gap-3 mb-4">
      <img src="<?php echo htmlspecialchars($avatarPath); ?>" class="profile-avatar" alt="Profile photo">
      <div>
        <h4 class="mb-0"><?php echo htmlspecialchars($user['fullname']); ?></h4>
        <div class="text-muted small">
          Member since <?php echo date('M Y', strtotime($user['created_at'])); ?>
        </div>
      </div>
    </div>

    <div id="profileAlert" class="alert"></div>

    <form id="profileForm" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Profile Photo</label>
        <input type="file" class="form-control" name="profile_image" accept="image/*">
      </div>
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" class="form-control" name="fullname" value="<?php echo htmlspecialchars($user['fullname']); ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
        <div class="form-text">Email can't be changed here — contact support if needed.</div>
      </div>
      <div class="mb-4">
        <label class="form-label">Mobile Number</label>
        <input type="tel" class="form-control" name="mobile_number" value="<?php echo htmlspecialchars($user['mobile_number']); ?>" required>
      </div>
      <button type="submit" class="btn btn-primary" id="profileSaveBtn">Save Changes</button>
      <a href="/front/includes/logout.php" class="btn btn-outline-secondary">Log out</a>
    </form>
  </div>
</div>

<script>
(function () {
    const form = document.getElementById('profileForm');
    const alertBox = document.getElementById('profileAlert');
    const saveBtn = document.getElementById('profileSaveBtn');

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        alertBox.style.display = 'none';
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving...';

        fetch('/front/includes/update-profile.php', {
            method: 'POST',
            body: new FormData(form)
        })
        .then(res => res.json())
        .then(function (data) {
            alertBox.className = 'alert alert-' + (data.success ? 'success' : 'danger');
            alertBox.textContent = data.message;
            alertBox.style.display = 'block';
            if (data.success) setTimeout(() => window.location.reload(), 900);
        })
        .catch(function () {
            alertBox.className = 'alert alert-danger';
            alertBox.textContent = 'Something went wrong. Please try again.';
            alertBox.style.display = 'block';
        })
        .finally(function () {
            saveBtn.disabled = false;
            saveBtn.textContent = 'Save Changes';
        });
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
