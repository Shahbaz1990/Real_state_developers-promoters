<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';

if (empty($_SESSION['front_user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in again.']);
    exit;
}
$userId = (int) $_SESSION['front_user_id'];

$fullname = trim($_POST['fullname'] ?? '');
$mobile   = trim($_POST['mobile_number'] ?? '');

if ($fullname === '' || !preg_match('/^[6-9]\d{9}$/', $mobile)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a valid name and 10-digit mobile number.']);
    exit;
}

$profileImagePath = null;

if (!empty($_FILES['profile_image']['name']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $ext = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed, true)) {
        echo json_encode(['success' => false, 'message' => 'Please upload a JPG, PNG, or WEBP image.']);
        exit;
    }
    if ($_FILES['profile_image']['size'] > 3 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'Image must be under 3MB.']);
        exit;
    }

    $uploadDir = __DIR__ . '/../../backend/uploads/profile/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $filename = 'user_' . $userId . '_' . time() . '.' . $ext;
    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $uploadDir . $filename)) {
        $profileImagePath = 'backend/uploads/profile/' . $filename;
    }
}

if ($profileImagePath) {
    $stmt = $conn->prepare("UPDATE users SET fullname = ?, mobile_number = ?, profile_image = ? WHERE id = ?");
    $stmt->bind_param('sssi', $fullname, $mobile, $profileImagePath, $userId);
} else {
    $stmt = $conn->prepare("UPDATE users SET fullname = ?, mobile_number = ? WHERE id = ?");
    $stmt->bind_param('ssi', $fullname, $mobile, $userId);
}
$stmt->execute();
$stmt->close();

$_SESSION['front_user_name'] = $fullname;

echo json_encode(['success' => true, 'message' => 'Profile updated successfully.']);
