<?php
/**
 * mailer.php — one function, sendOtpEmail(), used by register-send-otp.php.
 *
 * RECOMMENDED: install PHPMailer so you can send via real SMTP (Gmail,
 * SendGrid, your hosting's SMTP, etc). Most shared hosts silently drop
 * or spam-filter PHP's built-in mail() function.
 *
 *   composer require phpmailer/phpmailer
 *
 * Then fill in the SMTP_* constants below with your real credentials.
 * If vendor/autoload.php isn't found, this falls back to PHP's mail()
 * so the site doesn't hard-crash — but treat that as temporary only.
 */

// ---- SMTP settings: fill these in ----
define('SMTP_HOST', 'smtp.yourhost.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'noreply@tatitodevelopersandpromoters.com');
define('SMTP_PASSWORD', 'CHANGE_ME');
define('SMTP_FROM_EMAIL', 'noreply@tatitodevelopersandpromoters.com');
define('SMTP_FROM_NAME', 'Tatito Developers');

function sendOtpEmail(string $toEmail, string $toName, string $otp, string $purpose = 'register'): bool
{
    $subjectMap = [
        'register' => 'Verify your email — OTP inside',
        'login'    => 'Your login OTP',
        'reset'    => 'Reset your password — OTP inside',
    ];
    $subject = $subjectMap[$purpose] ?? 'Your OTP code';

    $bodyHtml = "
        <div style='font-family:Arial,sans-serif;max-width:480px;margin:auto'>
          <h2 style='color:#1f6feb;'>Tatito Developers</h2>
          <p>Hi " . htmlspecialchars($toName ?: 'there') . ",</p>
          <p>Your one-time verification code is:</p>
          <p style='font-size:28px;font-weight:700;letter-spacing:4px;color:#12213a'>{$otp}</p>
          <p>This code expires in 10 minutes. If you didn't request this, you can ignore this email.</p>
        </div>";

    $autoload = __DIR__ . '/../../vendor/autoload.php';

    if (file_exists($autoload)) {
        require_once $autoload;

        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USERNAME;
            $mail->Password   = SMTP_PASSWORD;
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = SMTP_PORT;

            $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
            $mail->addAddress($toEmail, $toName);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $bodyHtml;
            $mail->AltBody = "Your OTP is {$otp}. It expires in 10 minutes.";

            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log('OTP mail failed: ' . $e->getMessage());
            return false;
        }
    }

    // Fallback: native mail() — works only if the server is configured
    // for outbound mail. Replace this by installing PHPMailer above.
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . SMTP_FROM_NAME . " <" . SMTP_FROM_EMAIL . ">\r\n";

    return @mail($toEmail, $subject, $bodyHtml, $headers);
}
