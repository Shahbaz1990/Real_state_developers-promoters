<?php
/**
 * otp-functions.php — generate, store, and verify OTP codes against the
 * email_otps table. Include after $conn (mysqli) is available.
 */

function generateOtp(): string
{
    return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

/**
 * Creates a fresh OTP row for this email+purpose (invalidating older,
 * unused ones) and returns the raw 6-digit code to email to the user.
 */
function storeOtp(mysqli $conn, string $email, string $purpose): string
{
    // Invalidate any previous unused OTPs for this email/purpose so only
    // the newest code works.
    $stmt = $conn->prepare("UPDATE email_otps SET verified_at = NOW() WHERE email = ? AND purpose = ? AND verified_at IS NULL");
    $stmt->bind_param('ss', $email, $purpose);
    $stmt->execute();
    $stmt->close();

    $otp     = generateOtp();
    $otpHash = password_hash($otp, PASSWORD_DEFAULT);
    $expires = date('Y-m-d H:i:s', time() + 600); // 10 minutes

    $stmt = $conn->prepare("INSERT INTO email_otps (email, otp_hash, purpose, expires_at) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('ssss', $email, $otpHash, $purpose, $expires);
    $stmt->execute();
    $stmt->close();

    return $otp;
}

/**
 * Returns true/false, and sets $error by reference on failure.
 */
function verifyOtp(mysqli $conn, string $email, string $submittedOtp, string $purpose, ?string &$error = null): bool
{
    $stmt = $conn->prepare("SELECT id, otp_hash, expires_at, attempts FROM email_otps
                             WHERE email = ? AND purpose = ? AND verified_at IS NULL
                             ORDER BY id DESC LIMIT 1");
    $stmt->bind_param('ss', $email, $purpose);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        $error = 'No pending verification found. Please request a new OTP.';
        return false;
    }

    if (strtotime($row['expires_at']) < time()) {
        $error = 'This OTP has expired. Please request a new one.';
        return false;
    }

    if ((int) $row['attempts'] >= 5) {
        $error = 'Too many incorrect attempts. Please request a new OTP.';
        return false;
    }

    if (!password_verify($submittedOtp, $row['otp_hash'])) {
        $upd = $conn->prepare("UPDATE email_otps SET attempts = attempts + 1 WHERE id = ?");
        $upd->bind_param('i', $row['id']);
        $upd->execute();
        $upd->close();

        $error = 'Incorrect OTP. Please try again.';
        return false;
    }

    $upd = $conn->prepare("UPDATE email_otps SET verified_at = NOW() WHERE id = ?");
    $upd->bind_param('i', $row['id']);
    $upd->execute();
    $upd->close();

    return true;
}
