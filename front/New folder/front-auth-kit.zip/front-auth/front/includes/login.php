<?php
/**
 * front/includes/login.php
 * AJAX endpoint — password login for the front site.
 * Reuses the same `users` table as the admin panel; front logins are
 * simply not required to have role='admin'.
 */

if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../config.php';

$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$email    = trim(strtolower($input['email'] ?? ''));
$password = (string) ($input['password'] ?? '');

if ($email === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Please enter your email and password.']);
    exit;
}

$stmt = $conn->prepare("SELECT id, fullname, password, status, email_verified_at FROM users WHERE username = ? LIMIT 1");
$stmt->bind_param('s', $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user || !password_verify($password, $user['password'])) {
    echo json_encode(['success' => false, 'message' => 'Incorrect email or password.']);
    exit;
}
if ($user['status'] === 'Inactive') {
    echo json_encode(['success' => false, 'message' => 'This account has been disabled. Please contact support.']);
    exit;
}
if (!$user['email_verified_at']) {
    echo json_encode(['success' => false, 'message' => 'Please verify your email before logging in.', 'needs_verification' => true]);
    exit;
}

$_SESSION['front_user_id']    = $user['id'];
$_SESSION['front_user_name']  = $user['fullname'];
$_SESSION['front_user_email'] = $email;

echo json_encode(['success' => true, 'redirect' => '/front/profile.php']);
