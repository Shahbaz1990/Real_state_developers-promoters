<?php
/**
 * front/includes/register-send-otp.php
 * AJAX endpoint — step 1 of registration.
 * Validates the form, makes sure the email isn't already registered,
 * emails a 6-digit OTP, and stores the pending signup in the session
 * (NOT in the users table — that only happens after OTP verification).
 */

if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../config.php';       // gives us $conn (mysqli)
require_once __DIR__ . '/otp-functions.php';
require_once __DIR__ . '/mailer.php';

$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

$fullname = trim($input['fullname'] ?? '');
$email    = trim(strtolower($input['email'] ?? ''));
$mobile   = trim($input['mobile_number'] ?? '');
$password = (string) ($input['password'] ?? '');

// ---- Validate ----
if ($fullname === '' || $email === '' || $mobile === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Please fill in all required fields.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
    exit;
}
if (!preg_match('/^[6-9]\d{9}$/', $mobile)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a valid 10-digit mobile number.']);
    exit;
}
if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters.']);
    exit;
}

// ---- Already registered? ----
$stmt = $conn->prepare("SELECT id, email_verified_at FROM users WHERE username = ? LIMIT 1");
$stmt->bind_param('s', $email);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existing) {
    if ($existing['email_verified_at']) {
        echo json_encode(['success' => false, 'message' => 'This email is already registered. Please log in instead.']);
        exit;
    }
    // Exists but was never verified (abandoned signup) — let them retry via OTP.
}

// ---- Generate + email OTP ----
$otp = storeOtp($conn, $email, 'register');
$sent = sendOtpEmail($email, $fullname, $otp, 'register');

if (!$sent) {
    echo json_encode(['success' => false, 'message' => 'Could not send the OTP email. Please try again in a moment.']);
    exit;
}

// ---- Stash pending signup for step 2 (never store the raw password in DB pre-verification) ----
$_SESSION['pending_registration'] = [
    'fullname'      => $fullname,
    'email'         => $email,
    'mobile_number' => $mobile,
    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
    'expires_at'    => time() + 600,
];

echo json_encode(['success' => true, 'message' => 'OTP sent to ' . $email]);
