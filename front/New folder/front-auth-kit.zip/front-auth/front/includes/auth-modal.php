<style>
  #authModal .modal-content{ border-radius:1rem; border:none; }
  #authModal .auth-tabs{ display:flex; gap:.5rem; margin-bottom:1.25rem; }
  #authModal .auth-tab-btn{
    flex:1; border:none; background:#f7f8fa; color:#6b7686;
    border-radius:.6rem; padding:.6rem; font-weight:700; font-size:.92rem;
  }
  #authModal .auth-tab-btn.active{ background:#1f6feb; color:#fff; }
  #authModal .auth-panel{ display:none; }
  #authModal .auth-panel.active{ display:block; }
  #authModal .btn-auth-submit{ background:#1f6feb; border:none; width:100%; padding:.65rem; font-weight:600; }
  #authAlert{ display:none; }
  #authOtpStep{ display:none; }
  #authOtpDigits{ letter-spacing:6px; font-size:1.3rem; text-align:center; }
</style>

<div class="modal fade" id="authModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content p-2">
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title fw-bold">Welcome to Tatito Developers</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body pt-2">

        <div id="authAlert" class="alert"></div>

        <div class="auth-tabs">
          <button type="button" class="auth-tab-btn active" data-tab="login">Login</button>
          <button type="button" class="auth-tab-btn" data-tab="register">Register</button>
        </div>

        <!-- LOGIN -->
        <div class="auth-panel active" id="authPanelLogin">
          <form id="loginForm">
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" name="password" required>
            </div>
            <button type="submit" class="btn btn-auth-submit text-white">Login</button>
          </form>
        </div>

        <!-- REGISTER -->
        <div class="auth-panel" id="authPanelRegister">

          <form id="registerForm">
            <div class="mb-3">
              <label class="form-label">Full Name</label>
              <input type="text" class="form-control" name="fullname" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Mobile Number</label>
              <input type="tel" class="form-control" name="mobile_number" maxlength="10" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" name="password" minlength="6" required>
            </div>
            <button type="submit" class="btn btn-auth-submit text-white">Send OTP</button>
          </form>

          <!-- OTP step, shown after register form succeeds -->
          <div id="authOtpStep">
            <p class="text-muted small">
              We've sent a 6-digit code to <strong id="authOtpEmailLabel"></strong>.
            </p>
            <form id="otpForm">
              <div class="mb-3">
                <input type="text" class="form-control" id="authOtpDigits" name="otp" maxlength="6" inputmode="numeric" placeholder="------" required>
              </div>
              <button type="submit" class="btn btn-auth-submit text-white">Verify & Create Account</button>
              <button type="button" class="btn btn-link w-100 mt-1 small" id="authOtpResend">Resend code</button>
            </form>
          </div>

        </div>

      </div>
    </div>
  </div>
</div>

<script>
(function () {
    const alertBox = document.getElementById('authAlert');
    function showAlert(type, msg) {
        alertBox.className = 'alert alert-' + type;
        alertBox.textContent = msg;
        alertBox.style.display = 'block';
    }
    function hideAlert() { alertBox.style.display = 'none'; }

    // Tabs
    document.querySelectorAll('.auth-tab-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.auth-tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.auth-panel').forEach(p => p.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('authPanel' + (this.dataset.tab === 'login' ? 'Login' : 'Register')).classList.add('active');
            hideAlert();
        });
    });

    // ---- Login ----
    document.getElementById('loginForm').addEventListener('submit', function (e) {
        e.preventDefault();
        hideAlert();
        const data = Object.fromEntries(new FormData(this));

        fetch('/front/includes/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(function (res) {
            if (res.success) {
                window.location.href = res.redirect || '/front/profile.php';
            } else {
                showAlert('danger', res.message);
            }
        })
        .catch(() => showAlert('danger', 'Something went wrong. Please try again.'));
    });

    // ---- Register step 1: send OTP ----
    const registerForm = document.getElementById('registerForm');
    const otpStep = document.getElementById('authOtpStep');
    let registeredEmail = '';

    registerForm.addEventListener('submit', function (e) {
        e.preventDefault();
        hideAlert();
        const data = Object.fromEntries(new FormData(this));
        registeredEmail = data.email;

        fetch('/front/includes/register-send-otp.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(function (res) {
            if (res.success) {
                registerForm.style.display = 'none';
                otpStep.style.display = 'block';
                document.getElementById('authOtpEmailLabel').textContent = registeredEmail;
                showAlert('success', res.message);
            } else {
                showAlert('danger', res.message);
            }
        })
        .catch(() => showAlert('danger', 'Something went wrong. Please try again.'));
    });

    // ---- Register step 2: verify OTP ----
    document.getElementById('otpForm').addEventListener('submit', function (e) {
        e.preventDefault();
        hideAlert();
        const otp = document.getElementById('authOtpDigits').value.trim();

        fetch('/front/includes/register-verify-otp.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: registeredEmail, otp: otp })
        })
        .then(res => res.json())
        .then(function (res) {
            if (res.success) {
                window.location.href = res.redirect || '/front/profile.php';
            } else {
                showAlert('danger', res.message);
            }
        })
        .catch(() => showAlert('danger', 'Something went wrong. Please try again.'));
    });

    document.getElementById('authOtpResend').addEventListener('click', function () {
        registerForm.dispatchEvent(new Event('submit'));
    });
})();
</script>
