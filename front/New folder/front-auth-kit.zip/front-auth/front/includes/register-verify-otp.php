<?php
/**
 * front/includes/register-verify-otp.php
 * AJAX endpoint — step 2 of registration.
 * Checks the OTP the user typed in, and only NOW inserts the row into
 * `users`. Then logs the new user in.
 */

if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/otp-functions.php';

$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$email = trim(strtolower($input['email'] ?? ''));
$otp   = trim($input['otp'] ?? '');

$pending = $_SESSION['pending_registration'] ?? null;

if (!$pending || $pending['email'] !== $email) {
    echo json_encode(['success' => false, 'message' => 'Your registration session expired. Please start again.']);
    exit;
}
if (time() > $pending['expires_at']) {
    unset($_SESSION['pending_registration']);
    echo json_encode(['success' => false, 'message' => 'This registration attempt expired. Please start again.']);
    exit;
}

$error = null;
if (!verifyOtp($conn, $email, $otp, 'register', $error)) {
    echo json_encode(['success' => false, 'message' => $error]);
    exit;
}

// ---- OTP correct: create (or finish) the user row ----
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
$stmt->bind_param('s', $email);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existing) {
    // Abandoned-signup case: finish verifying the existing row.
    $userId = $existing['id'];
    $stmt = $conn->prepare("UPDATE users SET fullname = ?, mobile_number = ?, password = ?, email_verified_at = NOW() WHERE id = ?");
    $stmt->bind_param('sssi', $pending['fullname'], $pending['mobile_number'], $pending['password_hash'], $userId);
    $stmt->execute();
    $stmt->close();
} else {
    $stmt = $conn->prepare("INSERT INTO users (fullname, username, mobile_number, password, role, email_verified_at)
                             VALUES (?, ?, ?, ?, 'user', NOW())");
    $stmt->bind_param('ssss', $pending['fullname'], $pending['email'], $pending['mobile_number'], $pending['password_hash']);
    $stmt->execute();
    $userId = $stmt->insert_id;
    $stmt->close();
}

unset($_SESSION['pending_registration']);

// ---- Log the new user in ----
$_SESSION['front_user_id']   = $userId;
$_SESSION['front_user_name'] = $pending['fullname'];
$_SESSION['front_user_email'] = $email;

echo json_encode(['success' => true, 'message' => 'Account verified! You are now logged in.', 'redirect' => '/front/profile.php']);
