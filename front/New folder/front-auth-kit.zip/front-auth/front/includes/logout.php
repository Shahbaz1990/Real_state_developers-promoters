<?php
if (session_status() === PHP_SESSION_NONE) session_start();

unset($_SESSION['front_user_id'], $_SESSION['front_user_name'], $_SESSION['front_user_email']);
session_regenerate_id(true);

header('Location: /front/');
exit;
